#include "mainwindow.h"
#include <QtCharts>
#include "ui_mainwindow.h"
#include <qDebug>
#include <stdlib.h>
#include <time.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    showChart();
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::receiveData);
    timer->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showChart() {
    series = new QSplineSeries();
    series->append(0, 6);
    series->append(1, 4);
    series->append(2, 8);
    series->append(3, 4);
    series->append(4, 5);
    series->append(5,1);
    series->append(6,3);
    series->append(7,6);
    series->append(8,3);
    series->append(9,2);

    chart = new QChart();
    chart->addSeries(series);
    axisX = new QValueAxis();
    axisY = new QValueAxis();
    chart->addAxis(axisX,Qt::AlignBottom);
    chart->addAxis(axisY,Qt::AlignLeft);
    axisX->setRange(0, 40);
    axisX->setVisible(false);
    axisY->setRange(0, 10);
    series->attachAxis(axisX);
    series->attachAxis(axisY);
    chart->legend()->hide();
    chart->setTitle("line chart example");

    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);
}

void MainWindow::receiveData() {
    timer->stop();
    qreal now;
    mtx.lock();
    new_x += 1;
    now = new_x;
    mtx.unlock();
    if(series->count() > 40) {
        series->remove(0);
        axisX->setRange(now-40,now);
    }
    series->append(now,rand()%10);
    qDebug() << "add new item" << "(" << now << "," << 2 <<")";
    timer->start(1000);
}
