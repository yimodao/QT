#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts/QValueAxis>
#include <QtCharts/QSplineSeries>
#include <mutex>
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void showChart();
    Ui::MainWindow *ui;
    QSplineSeries* series = nullptr;
    QChart *chart = nullptr;
    bool stop_ = false;
    qreal new_x = 9;
    std::mutex mtx;
    QTimer* timer;
    QValueAxis* axisX = nullptr;
    QValueAxis* axisY = nullptr;
signals:
private slots:
    void receiveData();
};
#endif // MAINWINDOW_H
